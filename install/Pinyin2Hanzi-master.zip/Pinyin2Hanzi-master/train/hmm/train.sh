#!/bin/bash

python process_hzpy.py
python process_article.py
python gen_base.py
python process_finally.py