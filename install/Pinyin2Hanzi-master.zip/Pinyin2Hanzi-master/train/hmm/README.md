

## raw/
文本集合，txt后缀的文件，每个文件是一篇文章。

## pinyin2hanzi.txt
```
wo 我握
```

## middle.txt
基于`raw/`下的文件生成，每行一个不包含非中文的句子/单词。

## ../hmm_data/

states.txt
observations.txt


